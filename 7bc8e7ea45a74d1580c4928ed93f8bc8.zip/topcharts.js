$(document).ready(function(){
    $('body').fadeIn(1000);
    $('.listcontainer').hide();
  });